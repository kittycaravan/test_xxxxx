
function br(){
    document.write("<br>");
}

