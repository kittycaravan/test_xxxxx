
function br(){
    document.write("<br>");
}
function hr(){
    document.write("<hr>");
}
